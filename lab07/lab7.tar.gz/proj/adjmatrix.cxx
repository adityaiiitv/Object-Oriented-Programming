#include<iostream>
using namespace std;
int main()
{
	int i,j,k,x;
	
	cout<<"enter the number of vertices";
	cin>>x;
	int data[x][x];
	for(i=0;i<x;i++)
	{
	for(j=0;j<x;j++)
	{
		cin>>data[i][j];
		cout<<" ";
	}
	cout<<endl;
}
	i=0;
	j=0;
	for(i=0;i<x;i++)
	{
	for(j=0;j<x;j++)
	{
		if( data[i][j]==1)
		{
			cout<<i<<" is connected to"<<j<<"  ";
		}
	
	}
	
	cout<<endl;

}
}

