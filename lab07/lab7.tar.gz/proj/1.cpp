//Program to Sort an Array using Merge Sort

#include <stdio.h>

void merge_sort(int [], int, int);
void merge_array(int [], int, int, int);

main()
{
	int a[50], n, i;
	cout<<"\nEnter size of an array: ";
	cin>>n;
	cout<<"\nEnter elements of an array:\n";
	
	for(i=0; i<n; i++)
	cin>>a[i];

	merge_sort(a, 0, n-1);
	cin>>"\nAfter sorting:\n");

	for(i=0; i<n; i++)
	cout<<"\n%d"<< a[i]<<endl;

	getch();
}

void merge_sort(int a[], int beg, int end)
{
	int mid;
	
	if (beg < end)
	{
		mid = (beg+end)/2;

		merge_sort(a, beg, mid);
		merge_sort(a, mid+1, end);
		merge_array(a, beg, mid, end);
	}
}


void merge_array(int a[], int beg, int mid, int end)
{
	int i, left_end, num, temp, j, k, b[50];

	for(i=beg; i<=end; i++)
	b[i] = a[i];
	i = beg;
	j = mid+1;
	k = beg;

	while ((i<=mid) && (j<=end))
	{
		if (b[i] <= b[j])
		{
			a[k] = b[i];
			i++; k++;
		}
	
		else
		{
			a[k] = b[j];
			j++; k++;
		}
	}


	if (i <= mid)
	{
		while (i <= mid)
		{
			a[k] = b[i];
			i++; k++;
		}
	}
	
	else
	{
		while (j <= end)
		{
			a[k] = b[j];
			j++; k++;
		}
	}
}
