#include<iostream>
using namespace std;

int main()
{
int v;
cout<<"Enter no of Vertices: \n";
cin>>v;

int mat[v][v];
cout<<"Enter the Adjacency Matrix of the Graph: \n";

for(int i=0;i<v;i++) {
	for(int j=0;j<v;j++) {
		cin>>mat[i][j];
		}
	}
cout<<"The Adjacency List is: \n";
for(int i=0;i<v;i++) {
	cout<<"Adjacent Vertices of Vertex V"<<i+1<<" : ";
	for(int j=0;j<v;j++) {
		if (mat[i][j]==1) {
			cout<<"V"<<j+1<<"\t";
			}
		else {
			cout<<"  \t";
			}
		}
	cout<<"\n";
	}
	return 0;
}
