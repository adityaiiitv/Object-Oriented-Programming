#include <iostream>
#include <cstdlib>
using namespace std;
#define MAX 20
/*
 * Adjacency Matrix Class
 */
class Matrix
{
    private:
        int n;
        int **Adj;
        bool *visited;
    public:
        Matrix(int n)
        {
            this->n = n;
            visited = new bool [n];
            Adj = new int* [n];
            for (int i = 0; i < n; i++)
            {
                Adj[i] = new int [n];
                for(int j = 0; j < n; j++)
                {
                    Adj[i][j] = 0;
                }
            }
        }
        /*
         * Adding Edge to Graph
         */ 
        void adding_edges(int origin, int destination)
        {
           if( origin > n || destination > n || origin < 0 || destination < 0)
            {   
                cout<<"Entered Edge is Invalid!\n";
            }
            else
            {
                Adj[origin - 1][destination - 1] = 1;
            }
        }
        /*
         * Print the graph
         */ 
        void display()
        {
            int i,j;
            for(i = 0;i < n;i++)
            {
                for(j = 0; j < n; j++)
                    cout<<Adj[i][j]<<"  ";
                cout<<endl;
            }
        }
};
/*
 * Main Function
 */ 
int main()
{
    int nodes, max_edges, origin, destination;
    cout<<"Enter number of nodes: ";
    cin>>nodes;
    Matrix am(nodes);
    max_edges = nodes * (nodes - 1);
    for (int i = 0; i < max_edges; i++)
    {
        cout<<"Enter edge (-1 -1 to exit): ";
        cin>>origin>>destination;
        if((origin == -1) && (destination == -1))
            break;
        am.adding_edges(origin, destination);
    }
    am.display();
    return 0;
}
